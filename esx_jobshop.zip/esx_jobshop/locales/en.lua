Locales['en'] = {
  ['shop'] = 'Beszállító',
  ['shops'] = 'Beszállító',
  ['press_menu'] = 'Nyomj ~INPUT_CONTEXT~ hogy beszélj a beszállítóval!',
  ['shop_item'] = '$%s',
  ['bought'] = 'Vettél ~y~%sx~s~ ~b~%s~s~ ennyiért: ~r~$%s~s~',
  ['not_enough'] = 'Nincsen elég pénzed',
  ['player_cannot_hold'] = 'Nincsen elég szabad helyed!',
  ['shop_confirm'] = 'Vesz %sx %s ennyiért $%s?',
  ['no'] = 'Nem',
  ['yes'] = 'Igen',
}
